﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace calculator
{

    public partial class Window1 : Window
    {
        bool dod, min, raz, podz, pot, proc, pier, sil, Znak;
        void Boole()
        {
            dod = false;
            min = false;
            raz = false;
            podz = false;
            pot = false;
            Znak = false;
        }
        void Licz()
        {
            float a, b;
            string t = TextboxDzial.Text;
            if (dod == true) // dodawanie
            {
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("+")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("+") + 1));
                TextboxDzial.Text = (a + b).ToString();
            }
            else if (raz == true) //mnozenie
            {
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("x")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("x") + 1));
                TextboxDzial.Text = (a * b).ToString();
            }
            else if (podz == true) //dzielenie
            {
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("/")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("/") + 1));
                TextboxDzial.Text = (a / b).ToString();
            }
            else if (min == true) //minus
            {
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("-")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("-") + 1));
                TextboxDzial.Text = (a - b).ToString();
            }
            else if (pot == true) //potegowanie
            {
                float c = 1;
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("^")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("^") + 1));
                for (int i = 1; i <= b; i++)
                {
                    c = a * c;
                }
                TextboxDzial.Text = c.ToString();
            }
            else if (proc == true) //procenty
            {
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("%")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("%") + 1));
                TextboxDzial.Text = ((a * b) * 0.01).ToString();
            }
            else if (pier == true) //pierwiastkowanie
            {
                float c;
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("#")));
                b = Convert.ToSingle(t.Substring(t.IndexOf("#") + 1));
                c = 1 / a;
                c = Convert.ToSingle(Math.Pow(b, c));
                TextboxDzial.Text = c.ToString();
            }
            else if (sil == true) //silnia
            {
                int c = 1;
                a = Convert.ToSingle(t.Substring(0, t.IndexOf("!")));
                for (int i = 1; i <= a; i++)
                {
                    c *= i;
                }
                TextboxDzial.Text = c.ToString();
            }
            Boole();
            Znak = true;
        }
        public Window1()
        {
            InitializeComponent();

        }
        private void TextboxDzial_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextboxDzial.Text = "0";
        }
        private void Button0_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "0";
        }//0
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "1";
        }//1
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "2";
        }//2
        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "3";
        }//3
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "4";
        }//4
        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "5";
        }//5
        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "6";
        }//6
        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "7";
        }//7
        private void Button8_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "8";
        }//8
        private void Button9_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += "9";
        }//9
        private void ButtonCE_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text = " ";
            dod = false;
            min = false;
            raz = false;
            podz = false;
            sil = false;
            Znak = false;

        }//CE
        private void Buttonraz_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "x";
                raz = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                raz = true;
                TextboxDzial.Text += "x";

            }
        }//mnozenie
        private void Buttonpodz_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "/";
                podz = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                podz = true;
                TextboxDzial.Text += "/";
            }
        }//dzielenie
        private void Buttonmin_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "-";
                min = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                min = true;
                TextboxDzial.Text += "-";
            }
        }//odejmowanie
        private void Buttondod_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "+";
                dod = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                dod = true;
                TextboxDzial.Text += "+";
            }
        }//dodawanie
        private void Buttonpot_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "^";
                pot = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                pot = true;
                TextboxDzial.Text += "^";
            }
        }//potegowanie
        private void Buttonprze_Click(object sender, RoutedEventArgs e)
        {
            TextboxDzial.Text += ",";
        }//przecinek
        private void Buttonsil_Click(object sender, RoutedEventArgs e)
        {

            if (Znak == false)
            {
                TextboxDzial.Text += "!";
                sil = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                sil = true;
                TextboxDzial.Text += "!";
            }

        }//delete
        private void Buttonproc_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "%";
                proc = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                proc = true;
                TextboxDzial.Text += "%";
            }

        }//procent
        private void Buttonpier_Click(object sender, RoutedEventArgs e)
        {
            if (Znak == false)
            {
                TextboxDzial.Text += "#";
                pier = true;
                Znak = true;
            }
            else if (Znak == true)
            {
                Licz();
                pier = true;
                TextboxDzial.Text += "#";
            }
        }//pierwiastkowanie
        private void Buttonrow_Click(object sender, RoutedEventArgs e)//rowna sie
        {
            Licz();
        }  
    }
}
